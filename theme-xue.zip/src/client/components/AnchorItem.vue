<template>
    <div :class="itemClass">
        <router-link :to='itemLink' class="anchor-title-link">{{ title }}</router-link>
        <div v-if='children && children.length > 0' class="items">
            <anchor-item
                v-for='(child, index) in children'
                :key='index'
                :is-top='false'
                :title='child.title'
                :slug='child.slug'
            />
        </div>
    </div>
</template>

<script setup>
    import { computed } from 'vue';
    import { useRoute } from 'vue-router';
    import AnchorItem from './AnchorItem.vue'

    const currRoute = useRoute()

    const props = defineProps({
        title: {
            type: String,
            required: true
        },
        slug: {
            type: String,
            required: true
        },
        children: {
            type: Array,
            default: []
        },
        isTop: {
            type: Boolean,
            default: true
        },
        onlyOne: {
            type: Boolean,
            default: false
        }
    })

    const isActive = () => {
        const { fullPath } = currRoute
        const hashIndex = fullPath.lastIndexOf('#')
        if (hashIndex === -1) {
            return false
        }
        const foundTitle = decodeURI(fullPath.substring(hashIndex + 1))

        return props.title === foundTitle
    }

    const itemClass = computed(() => {
        const classes = ['anchor-item-wrapper']

        if (isActive()) {
            classes.push('active')
        }

        if (!props.isTop) {
            classes.push('child')
        }

        if (props.onlyOne) {
            classes.push('no-line')
        }

        if (props.children && props.children.length > 0) {
            classes.push('has-child')
        }

        return classes
    })

    const itemLink = computed(() => {
        return { hash: `#${props.slug}`, query: { smoothed: 1 } }
    })
</script>

<style lang="less" scoped>
    @import '../styles/main.less';

    // variables
    @item-left-padding: 24px;
    @item-circle-radius: 6px;
    @link-height: 1.5em;

    .anchor-item-wrapper {
        display: flex;
        flex-direction: column;
        padding-left: @item-left-padding;
        box-sizing: border-box;
        position: relative;

        &::after {
            content: '';
            position: absolute;
            width: 2px;
            left: (@item-left-padding / 2) - 1px;
            top: 0;
            height: 100%;
            background: @primary-color;
        }

        &::before {
            content: '';
            position: absolute;
            left: @item-circle-radius;
            top: calc(@link-height / 2 - @item-circle-radius + 0.4em);
            width: @item-circle-radius * 2;
            height: @item-circle-radius * 2;
            background: @primary-color;
            border-radius: 100%;
            box-shadow: 0 0 4px @secondary-color;
        }
        
        &:first-child {
            &::after {
                top: 0.4em + (@link-height / 2);
                height: calc(100% - (0.4em + (@link-height / 2)));
            }
        }

        &:last-child {
            &::after {
                top: 0;
                height: 50%;
            }

            &.has-child{
                &::after {
                    height: 100%;
                }
            }
        }

        &.no-line {
            &::after {
                display: none;
            }

            &.has-child {
                &::after {
                    top: 0.4em + (@link-height / 2);
                    display: inline-block;
                    height: calc(100% - (0.4em + (@link-height / 2)));
                }
            }
        }

        .anchor-title-link {
            color: #333;
            display: flex;
            height: @link-height;
            align-items: center;
            padding: 0.4em 0;

            &:hover {
                color: @primary-color;
            }
        }

        &.active {
            &>.anchor-title-link {
                font-weight: bold;
                color: @primary-color;
            }
        }

        &.child {
            padding-left: (@item-left-padding / 3);

            &::before, &::after {
                display: none;
            }
        }
    }
</style>