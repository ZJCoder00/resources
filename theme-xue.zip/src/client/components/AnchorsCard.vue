<template>
    <card title='目录'>
        <div class="anchors-card">
            <scroll-area>
                <anchor-item
                    v-for='(anchor, index) in anchors'
                    :key='index'
                    :title='anchor.title'
                    :slug='anchor.slug'
                    :children='anchor.children'
                    :only-one='anchors.length === 1'
                />                
            </scroll-area>
        </div>
    </card>
</template>

<script setup>
    import { usePageData } from '@vuepress/client';
    import { computed } from 'vue';
    import Card from '@xue/Card.vue'
    import AnchorItem from '@xue/AnchorItem.vue'
    import ScrollArea from '@xue/ScrollArea.vue'

    const pageData = usePageData()

    const anchors = computed(() => {
        const anchors = pageData.value.headers.map(({ title, children, slug }) => {
            return { title, children, slug }
        })
        return anchors
    })
</script>

<style lang="less" scoped>
    .anchors-card {
        width: 100%;
        margin-top: 4px;
        display: flex;
        flex-direction: column;
    }
</style>