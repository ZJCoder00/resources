<template>
    <div class="aside-bar">
        <card>
            <avatar shape='circle' :src="avatarImage" style='box-shadow: 0 0 15px #e7bea977;' />
            <div class="username">{{ username }}</div>
            <div class="description">{{ description }}</div>
            <div class="simple-info">
                <router-link to='/page/1'>
                    <div class="section">
                        <div class="header">文章数</div>
                        <span>{{ numPosts }}</span>
                    </div>                    
                </router-link>
                <router-link to='/tags'>
                    <div class="section">
                        <div class="header">标签数</div>
                        <span>{{ numTags }}</span>
                    </div>                    
                </router-link>
                <router-link to='/links'>
                    <div class="section">
                        <div class="header">好友数</div>
                        <span>{{ numFriends }}</span>
                    </div>                    
                </router-link>
            </div>
        </card>
        <card v-if='!postMode' title='社交账号'>
            <div class="socials">
                <tooltip v-for='(item, index) in socialAccounts' :key='index' :hint='item.title'>
                    <a :href="item.url" class="social-icon">
                        <m-icon :name='item.icon' />
                    </a>
                </tooltip>
            </div>
        </card>
        <anchors-card v-else />
        <weather-card v-if='!postMode' />
        <tag-card v-else-if='frontmatter?.tags?.length > 0' />
    </div>
</template>

<script setup>
    import { computed, ref } from 'vue';
    import { useRoute, useRouter } from 'vue-router';
    import { useThemeData } from '@vuepress/plugin-theme-data/lib/client'
    import { usePageData, usePageFrontmatter } from '@vuepress/client';
    import Card from '@xue/Card.vue'
    import Avatar from '@xue/Avatar.vue'
    import WeatherCard from '@xue/WeatherCard.vue'
    import Tooltip from '@xue/Tooltip.vue'
    import AnchorsCard from '@xue/AnchorsCard.vue'
    import TagCard from '@xue/TagCard.vue'
    import { useBlogTags, useFriendsCounter } from '../composables'

    const router = useRouter()
    const pageData = usePageData()
    const frontmatter = usePageFrontmatter()
    const themeData = useThemeData()
    const blogTags = useBlogTags()
    const friendsCounter = useFriendsCounter()

    defineProps({
        postMode: {
            type: Boolean,
            default: false
        }
    })

    const username = computed(() => {
        return themeData.value.user.name
    })

    const description = computed(() => {
        return themeData.value.user.bio
    })

    const avatarImage = computed(() => {
        return themeData.value.user.avatar
    })

    // todo
    const numPosts = computed(() => {
        let count = 0
        for (const route of router.getRoutes()) {
            const { path } = route
            const isHtmlFile = path.endsWith('.html')
            const isInPostFolder = path.startsWith(__POST_FOLDER__)
            if (isHtmlFile && isInPostFolder) {
                count++
            }
        }
        return count
    })

    const numTags = computed(() => {
        return Object.keys(blogTags.value).length || 0
    })

    const numFriends = computed(() => {
        return friendsCounter.value || 0
    })

    const socialAccounts = computed(() => {
        return themeData.value.social
    })

</script>

<style lang="less" scoped>
    .aside-bar {
        width: 250px;
        display: flex;
        flex-direction: column;
        row-gap: 10px;
        flex-shrink: 0;
        overflow-y: auto;
        height: calc(100vh - 55px - 1em - 10px);
        box-sizing: border-box;
        padding-bottom: 20px;

        &::-webkit-scrollbar {
            display: none;
        }

        .username {
            font-family: 等线;
            font-size: 20px;
        }

        .description {
            font-family: 等线;
            font-size: 14px;
            color: #666;
        }

        .simple-info {
            display: flex;
            width: 100%;
            font-family: 等线;
            margin-top: 5px;

            a {
                flex: 1;
                color: #000;
            }

            .section {
                flex: 1;
                display: flex;
                flex-direction: column;
                justify-content: center;
                align-items: center;
                row-gap: 5px;
                user-select: none;

                &:hover {
                    cursor: pointer;

                    span {
                        color: #e7bea9;
                    }
                }

                .header {
                    font-size: 14px;
                    color: #999;
                }

                span {
                    transition: color 0.4s;
                }
            }
        }

        .socials {
            display: flex;
            flex-wrap: wrap;
            width: 100%;
            padding: 0 20px;
            box-sizing: border-box;
            margin-top: 10px;
            justify-content: center;
            column-gap: 15px;

            .social-icon {
                width: 32px;
                height: 32px;
                border-radius: 100%;
                display: flex;
                justify-content: center;
                align-items: center;
                background: #e8e9e9;

                &:hover {
                    cursor: pointer;
                }

                &:last-child {
                    margin-right: 0;
                }

                i {
                    color: #000;
                }
            }
        }
    }
</style>