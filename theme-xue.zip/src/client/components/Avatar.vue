<template>
    <div :class="avatarClass" :style='style'>
        <img :src='src'>
    </div>
</template>

<script setup>
import { computed } from 'vue';

    const props = defineProps({
        src: {
            type: String,
            required: true
        },
        // 'normal' | 'round' | 'circle'
        shape: {
            type: String,
            default: 'normal',
        },
        style: Object
    })

    const avatarClass = computed(() => {
        const classes = ['avatar']

        if (props.shape !== 'normal') {
            classes.push(props.shape)
        }

        return classes
    })
</script>

<style lang="less" scoped>
    .avatar {
        width: 80px;
        height: 80px;
        overflow: hidden;
        position: relative;
        display: flex;
        justify-content: center;
        align-items: center;

        img {
            width: 100%;
            height: 100%;
        }

        &.round {
            border-radius: 6px;
        }

        &.circle {
            border-radius: 100%;
        }
    }
</style>