<template>
    <div class="background"></div>
</template>

<script setup>
    defineProps({
        src: {
            type: String,
            required: true
        }
    })
</script>

<style lang="less" scoped>
    .background {
        position: fixed;
        left: 0;
        top: 0;
        width: 100vw;
        height: 100vh;
        background-image: v-bind(src);
        filter: blur(15px);
        pointer-events: none;
        z-index: -10;
        background-repeat: no-repeat;
        background-size: cover;
        background-position: center center;
        opacity: .2;
    }
</style>