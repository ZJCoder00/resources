<template>
    <div ref='rootRef' class="card" :style='style'>
        <div v-if='title' class="title">{{ title }}</div>
        <slot></slot>
    </div>
</template>

<script setup>
    import { ref } from 'vue';

    defineProps({
        title: String,
        style: Object
    })

    const rootRef = ref(null)

    defineExpose({ rootRef })
</script>

<style lang="less" scoped>
    @import '../styles/main.less';
    
    .card {
        padding: 20px 10px;
        background: #fff;
        border-radius: 12px;
        display: flex;
        flex-direction: column;
        align-items: center;
        box-shadow: 0 0 10px #e7bea966;
        row-gap: 5px;

        &::-webkit-scrollbar {
            width: 6px;
        }

        &::-webkit-scrollbar-thumb {
            border-radius: 999px;
            background: #cecece;
        }

        &::-webkit-scrollbar-track {
            border-radius: 999px;
            background: #efefef;
        }

        &>.title {
            font-family: 等线;
            font-weight: bold;
            width: 100%;
            position: relative;
            box-sizing: border-box;
            padding-left: 12px;
            color: #333;
            user-select: none;

            &::before {
                position: absolute;
                left: 0;
                content: '';
                width: 6px;
                height: 100%;
                background: @theme-color;
                border-radius: 999px;
            }
        }
    }
</style>