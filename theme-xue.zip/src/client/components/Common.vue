<template>
  <background :src='`url(${pageBackgroundSrc})`' />
  <nav-bar />
  <container>
    <card ref='rootRef' style='flex: 1; overflow-y: auto; max-height: calc(100% - 35px)'>
      <slot />
    </card>
    <aside-bar :post-mode='isPost' />
  </container>
  <my-footer />
</template>

<script setup>
  import { computed, onMounted, provide, ref } from 'vue'
  import { usePageFrontmatter, ClientOnly } from '@vuepress/client'
  import { useThemeData } from '@vuepress/plugin-theme-data/lib/client'
  // Components
  import NavBar from '@xue/NavBar.vue'
  import Background from '@xue/Background.vue'
  import Container from '@xue/Container.vue'
  import Card from '@xue/Card.vue'
  import AsideBar from '@xue/AsideBar.vue'
  import MyFooter from '@xue/Footer.vue'
  import { useActiveHeaderLinks } from '../composables/useActiveHeaderLinks'

  // Composables
  const frontmatter = usePageFrontmatter()
  const themeData = useThemeData()
  const rootRef = ref(null)

  if (props.isPost) {
    useActiveHeaderLinks(rootRef)
  }

  // Properties
  const props = defineProps({
    isPost: {
      type: Boolean,
      default: false
    }
  })

  const pageBackgroundSrc = computed(() => {
    if (frontmatter.value.bgSrc) {
      return frontmatter.value.bgSrc
    }

    return themeData.value.defaultBackground
  })
</script>

<style lang="less">
  @import "../styles/remixicon/remixicon.css";

  * {
    margin: 0;
    padding: 0;
  }

  a {
    text-decoration: none;
  }
</style>
