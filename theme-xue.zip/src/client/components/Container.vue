<template>
    <div class="container">
        <slot></slot>
    </div>
</template>

<script setup>
    defineProps({
        width: {
            type: String,
            default: '1100px'
        }
    })
</script>

<style lang="less" scoped>
    .container {
        width: v-bind(width);
        height: calc(100vh - 55px - 1em - 10px);
        display: flex;
        align-items: flex-start;
        box-sizing: border-box;
        padding: 15px 5px 10px 5px;
        margin: 0 auto;
        column-gap: 20px;
        position: relative;
    }
</style>