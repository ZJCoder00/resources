<template>
    <div class="footer">
        <span>A Vuepress theme owned by {{ ownerName }}, designed by </span>
        <a :href='designerUrl'>@{{ designer }}</a>
    </div>
</template>

<script setup>
    import { computed, ref } from 'vue';
    import { useThemeData } from '@vuepress/plugin-theme-data/lib/client'

    const themeData = useThemeData()

    const designer = ref('mythic-p')
    const designerUrl = ref('https://github.com/mythic-p')

    const ownerName = computed(() => {
        return themeData.value.user.name
    })

    const owner = ref('c-an')
</script>

<style lang="less" scoped>
    @import '../styles/main.less';

    .footer {
        font-family: 等线;
        color: #999;
        position: fixed;
        bottom: 10px;
        left: 50%;
        transform: translateX(-50%);

        a {
            color: @primary-color;
        }
    }
</style>