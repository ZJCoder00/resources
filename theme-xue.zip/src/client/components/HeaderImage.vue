<template>
    <router-link :to='to' :class="myClass">
        <img :src='src' class="image">        
    </router-link>
</template>

<script setup>
import { computed } from 'vue';

    const props = defineProps({
        src: {
            type: String,
            required: true
        },
        to: String,
        hoverEffect: {
            type: Boolean,
            default: false
        }
    })

    const myClass = computed(() => {
        const classes = ['header-image']

        if (props.hoverEffect) {
            classes.push('effect')
        }

        return classes
    })
</script>

<style lang="less" scoped>
    .header-image {
        width: 100%;
        border-radius: 12px;
        overflow: hidden;

        &.effect {
            .image {
                filter: blur(3px);
                transition: filter 0.8s, transform 0.8s;                
            }
        }

        .image {
            width: 100%;
            height: 100%;
        }

        &:hover {

            &.effect .image {
                filter: blur(0);
                transform: scale(1.1);
            }
        }
    }
</style>