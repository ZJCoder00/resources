<template>
    <i :class="['icon', `ri-${name}`]" @click='onClick'></i>
</template>

<script setup>
    const props = defineProps({
        size: {
            type: String,
            default: '24px'
        },
        name: {
            type: String,
            required: true
        }
    })

    const emits = defineEmits(['click'])

    const onClick = () => {
        emits('click')
    }
</script>

<style lang="less" scoped>
    .icon {
        font-size: v-bind(size);
    }
</style>