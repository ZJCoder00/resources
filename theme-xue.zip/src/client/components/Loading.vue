<template>
    <div class="loading">
        <div v-if='isLoading' class="wrapper">
            <span class="hint">{{ hint }}</span>
        </div>
        <slot v-else />
    </div>
</template>

<script setup>
    defineProps({
        isLoading: {
            type: Boolean,
            default: false
        },
        hint: {
            type: String,
            default: '加载中...'
        }
    })
</script>

<style lang="less" scoped>
    .loading {
        .wrapper {
            display: flex;
            flex-direction: column;
            align-items: center;

            span {
                color: #999;
                font-size: 14px;
            }
        }
    }
</style>