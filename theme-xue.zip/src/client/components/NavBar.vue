<template>
    <div class="nav-bar">
        <div class="wrapper">
            <router-link v-for='(item, index) in navItems' :key='index' :to='item.url' :class="['item', index === currNav ? 'active' : '']">{{ item.name }}</router-link>
        </div>
    </div>
</template>

<script setup>
    import { computed, ref } from 'vue';
    import { useRoute, useRouter } from 'vue-router';
    import { useThemeData } from '@vuepress/plugin-theme-data/lib/client'

    const currRoute = useRoute()
    const themeData = useThemeData()

    const navItems = computed(() => {
        return Object.entries(themeData.value.navBar)
            .map(item => {
                const [key, value] = item
                return { name: value, url: key }
            })
    })

    const currNav = computed(() => {
        const { path } = currRoute
        if (path.length === 1) {
            return 0
        }
        let index = 0
        for (const url of Object.keys(themeData.value.navBar)) {
            const name = url.substring(1)
            if (name.length === 0) {
                index++
                continue
            }
            if (path.startsWith(name, 1)) {
                return index
            }
            index++
        }
        // fallback to 0
        return 0
    })
</script>

<style lang="less" scoped>
    .nav-bar {
        width: 100%;
        height: 55px;
        background: #fff;
        display: flex;
        justify-content: center;
        position: relative;

        .wrapper {
            width: 1090px;
            display: flex;
            height: 100%;
            position: relative;

            .item {
                width: 100px;
                height: 100%;
                display: flex;
                justify-content: center;
                align-items: center;
                user-select: none;
                position: relative;
                color: #333;

                &:hover {
                    cursor: pointer;
                }

                &.active {
                    &::after {
                        content: '';
                        position: absolute;
                        left: 50%;
                        bottom: 10%;
                        transform: translateX(-50%);
                        width: 80%;
                        height: 4px;
                        border-radius: 999px;
                        background-color: #e7bea9;
                        box-shadow: 0 0 14px #e7bea9;
                    }
                }
            }
        }
    }
</style>
