<template>
    <div class="pager">
        <router-link :to=' `${prefix}${Math.max(currPage - 1, 1)}`' :class='prevButtonClass'>
            <m-icon name='arrow-left-s-line' />
        </router-link>
        <router-link :to='`${prefix}1/`' :class="makeBlockClass(1)">1</router-link>
        <div class="block more" v-if="currPage - 1 > 2">...</div>
        <router-link v-if='totalPages > 2' :to='`${prefix}${clamp(currPage - 1, 2, totalPages - 3)}/`' :class="makeBlockClass(clamp(currPage - 1, 2, totalPages - 3))">{{ clamp(currPage - 1, 2, totalPages - 3) }}</router-link>
        <router-link v-if='totalPages > 3' :to='`${prefix}${clamp(currPage, 3, totalPages - 2)}/`' :class="makeBlockClass(clamp(currPage, 3, totalPages - 2))">{{ clamp(currPage, 3, totalPages - 2) }}</router-link>
        <router-link v-if='totalPages > 4' :to='`${prefix}${clamp(currPage + 1, 4, totalPages - 1)}/`' :class="makeBlockClass(clamp(currPage + 1, 4, totalPages - 1))">{{ clamp(currPage + 1, 4, totalPages - 1) }}</router-link>
        <div v-if="totalPages - currPage > 2" class="block more">...</div>
        <router-link v-if="totalPages > 1" :to='`${prefix}${totalPages}/`' :class="makeBlockClass(totalPages)">{{ totalPages }}</router-link>
        <router-link :to='`${prefix}${Math.min(currPage + 1, totalPages)}`' :class="nextButtonClass">
            <m-icon name='arrow-right-s-line' />
        </router-link>
    </div>
</template>

<script setup>
    import { clamp } from '../utils'
    import { computed } from 'vue';

    const props = defineProps({
        currPage: {
            type: Number,
            default: 1
        },
        totalPages: {
            type: Number,
            default: 10
        },
        allowJump: {
            type: Boolean,
            default: false
        },
        prefix: {
            type: String,
            default: '/page/'
        }
    })

    const prevButtonClass = computed(() => {
        const classes = ['block']

        if (props.currPage === 1) {
            classes.push('disabled')
        }

        return classes
    })

    const nextButtonClass = computed(() => {
        const classes = ['block']

        if (props.currPage === props.totalPages) {
            classes.push('disabled')
        }

        return classes
    })

    const makeBlockClass = page => {
        const classes = ['block']

        if (props.currPage === page) {
            classes.push('active')
        }

        return classes
    }
</script>

<style lang="less" scoped>
    @import "../styles/main.less";

    a {
        color: #000;
    }

    .pager {
        display: flex;
        justify-content: center;

        .block {
            width: 32px;
            height: 32px;
            display: flex;
            justify-content: center;
            align-items: center;
            transition: color 0.4s;

            &.active {
                border-radius: 100%;
                background: @secondary-color;
                color: @primary-color !important;
            }

            &:hover {
                color: @primary-color;
                cursor: pointer;
            }

            &.disabled {
                color: #999;
                pointer-events: none;
            }

            &.more {
                color: #000;
            }
        }
    }
</style>