<template>
    <div class="post-list"></div>
</template>

<script setup></script>

<style lang="less" scoped>
    .post-list {
        display: flex;
        flex-direction: column;
    }
</style>