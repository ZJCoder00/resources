<template>
    <div :class="scrollAreaClass">
        <slot />
    </div>
</template>

<script setup>
    import { computed } from 'vue';

    const props = defineProps({
        size: {
            type: String,
            default: '300px'
        },
        scrollH: {
            type: Boolean,
            default: false
        }
    })

    const scrollAreaClass = computed(() => {
        const classes = ['scroll-area']

        if (props.scrollH) {
            classes.push('horizontal')
        }

        return classes
    })
</script>

<style lang="less" scoped>
    .scroll-area {
        max-height: v-bind(size);
        overflow-y: auto;
        overflow-x: hidden;

        &.horizontal {
            overflow-y: hidden;
            overflow-x: auto;
        }

        &::-webkit-scrollbar {
            width: 6px;
        }

        &::-webkit-scrollbar-thumb {
            border-radius: 999px;
            background: #cecece;
        }

        &::-webkit-scrollbar-track {
            border-radius: 999px;
            background: #efefef;
        }
    }
</style>