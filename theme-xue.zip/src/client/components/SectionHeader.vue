<template>
    <div class="section-header">
        <span class="main">{{ title }}</span>
        <span v-if='subTitle' class="sub">{{ subTitle }}</span>
    </div>
</template>

<script setup>
    defineProps({
        title: {
            type: String,
            required: true
        },
        subTitle: String
    })
</script>

<style lang="less" scoped>
    @import "../styles/main.less";

    .section-header {
        display: flex;
        align-items: flex-end;
        position: relative;
        column-gap: 10px;
        font-family: 等线;

        &:hover {

            &::before {
                width: 40%;
            }
        }

        &::before {
            position: absolute;
            content: '';
            bottom: -6px;
            height: 6px;
            width: 30%;
            left: 0;
            background: @theme-color;
            box-shadow: 0 0 6px @theme-color;
            border-radius: 6px;
            transition: width 0.4s;
        }

        .main {
            font-size: 28px;
        }

        .sub {
            text-transform: uppercase;
            color: #999;
        }
    }
</style>