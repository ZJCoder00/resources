<template>
    <div v-if='!href' class="tag">
        <m-icon v-if='icon' :name='icon' :size='iconSize' />
        <slot />
    </div>
    <router-link v-else :to='href' class="tag">
        <m-icon v-if='icon' :name='icon' :size='iconSize' />
        <slot />        
    </router-link>
</template>

<script setup>
    defineProps({
        icon: String,
        iconSize: {
            type: String,
            default: '16px'
        },
        href: String
    })
</script>

<style lang="less" scoped>
    @import "../styles/main.less";

    .tag {
        display: flex;
        align-items: center;
        padding: 4px 12px;
        border-radius: 999px;
        background: @secondary-color;
        color: @primary-color;
        column-gap: 8px;
    }
</style>