<template>
    <card title='文章标签' style='align-items: stretch'>
        <scroll-area>
            <tags :items='tags' style='font-size: 14px' />
        </scroll-area>
    </card>
</template>

<script setup>
    import { computed } from 'vue'
    import { usePageFrontmatter } from '@vuepress/client'
    import Card from '@xue/Card.vue'
    import ScrollArea from '@xue/ScrollArea.vue'
    import Tags from '@xue/Tags.vue'

    const frontmatter = usePageFrontmatter()

    const tags = computed(() => {
        const formattedTags = (frontmatter.value.tags || []).map(tag => {
            return { name: tag, href: `/tags/${tag}` }
        })
        return formattedTags
    })
</script>

<style lang="less" scoped></style>