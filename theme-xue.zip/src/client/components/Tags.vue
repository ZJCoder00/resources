<template>
    <div class="tags" :style='style'>
        <tag v-for='(tag, index) in items' :key='index' :icon='tag.icon' :href="tag.href || null">{{ tag.name }}</tag>
    </div>
</template>

<script setup>
    import Tag from './Tag.vue'

    defineProps({
        // { name: string, icon?: string, href?: string }[]
        items: {
            type: Array,
            required: true
        },
        style: Object
    })
</script>

<style lang="less" scoped>
    .tags {
        display: flex;
        align-items: center;
        flex-wrap: wrap;
        row-gap: 16px;
        column-gap: 12px;
        width: 100%;
    }
</style>