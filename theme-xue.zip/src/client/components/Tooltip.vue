<template>
    <div class="tooltip">
        <span class="content">{{ hint }}</span>
        <slot></slot>
    </div>
</template>

<script setup>
    const props = defineProps({
        hint: {
            type: String,
            required: true
        }
    })
</script>

<style lang="less" scoped>
    .tooltip {
        position: relative;

        &>.content {
            position: absolute;
            left: 50%;
            top: 0;
            opacity: 0;
            pointer-events: none;
            color: #fff;
            background: #333;
            padding: 5px;
            border-radius: 4px;
            transition: opacity 0.4s, transform 0.4s;
            font-size: 12px;
            transform: translate(-50%, -50%);
            white-space: nowrap;
        }

        &:hover {
            &>.content {
                transform: translate(-50%, -100%);
                opacity: 1;
            }
        }
    }
</style>
