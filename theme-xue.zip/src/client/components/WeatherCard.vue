<template>
    <card title='今日天气'>
        <loading :is-loading="!weatherInited">
            <div class="weather-info-wrapper">
                <div class="weather">
                    <img :src="weatherInfo.weatherImage">
                </div>
                <div class="temperature">{{ weatherInfo.lowTemp }} ~ {{ weatherInfo.highTemp }} ℃</div>
                <div class="weather-text">{{ weatherInfo.city }} {{ weatherInfo.weather }}</div>            
            </div>
        </loading>
    </card>
</template>

<script setup>
    import { reactive, onMounted, ref } from 'vue'
    import { useThemeData } from '@vuepress/plugin-theme-data/lib/client'
    import { get } from '../utils/axios'
    import Card from '@xue/Card.vue'
    import Loading from '@xue/Loading.vue'
    // weather images
    import WeatherSnowy from '../assets/weather/snowy.svg'
    import WeatherThunder from '../assets/weather/thunder.svg'
    import WeatherRainy from '../assets/weather/rainy.svg'
    import WeatherCloudy from '../assets/weather/cloudy.svg'
    import WeatherDay from '../assets/weather/day.svg'
    import WeatherNight from '../assets/weather/night.svg'

    const themeData = useThemeData()

    const weatherInfo = reactive({ city: '', weather: '', weatherImage: '', highTemp: 0, lowTemp: 0 })
    const weatherInited = ref(false)

    onMounted(() => {
        const { appId: appid, appSecret: appsecret } = themeData.value.weatherApi

        get('https://v0.yiketianqi.com/free/day', { appid, appsecret, vue: '1' }).then(resp => {
            const { city, wea, wea_img, tem_day, tem_night } = resp.data
            weatherInfo.city = city
            weatherInfo.weather = wea
            weatherInfo.weatherImage = wea_img
            weatherInfo.highTemp = tem_day
            weatherInfo.lowTemp = tem_night

            let image
            switch (wea_img) {
                case 'xue':
                    image = WeatherSnowy
                    break
                case 'lei':
                    image = WeatherThunder
                    break
                case 'yu':
                    image = WeatherRainy
                    break
                case 'yin':
                    image = WeatherCloudy
                    break
                case 'yun':
                    image = WeatherCloudy
                    break
                case 'qing':
                    image = WeatherDay
                    break
                case 'shachen':
                case 'wu':
                case 'bingbao':
                    image = WeatherNight
                    break
            }

            weatherInfo.weatherImage = image
            weatherInited.value = true
        })
    })
</script>

<style lang="less" scoped>
    .weather-info-wrapper {
        display: flex;
        flex-direction: column;

        .weather {
            width: 64px;
            height: 64px;
            overflow: hidden;
            display: flex;
            justify-content: center;
            align-items: center;
            position: relative;

            img {
                width: 80px;
                height: 80px;
            }
        }

        .temperature {
            color: #999;
            font-size: 14px;
        }        
    }

</style>