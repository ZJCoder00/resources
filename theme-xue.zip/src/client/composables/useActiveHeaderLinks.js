import { usePageData } from '@vuepress/client'
import _ from 'lodash'
import { onBeforeUnmount, onMounted, watch, ref } from 'vue'
import { useRoute, useRouter } from 'vue-router'

const debounceDelay = 200
const scrollOffset = 5
const headerLinkSelector = 'a.anchor-title-link'
const headerAnchorSelector = 'a.header-anchor'

export const useActiveHeaderLinks = (rootRef) => {
    const router = useRouter()
    const route = useRoute()
    const pageData = usePageData()

    const replaceWithoutScroll = async route => {
        const { scrollBehavior } = router.options
        router.options.scrollBehavior = undefined
        await router.replace(route).finally(() => { router.options.scrollBehavior = scrollBehavior })
    }

    const resolveRootElement = () => {
        if (!rootRef || !rootRef.value) {
            return null
        }
        return rootRef.value.rootRef
    }

    const setRouteActiveHash = () => {
        const rootElement = resolveRootElement()
        if (!rootElement) {
            return
        }
        const scrollTop = rootElement.scrollTop
        const isAtPageTop = Math.abs(scrollTop - 0) < scrollOffset
        if (isAtPageTop) {
            replaceWithoutScroll({ hash: '', force: true })
            return
        }
        const scrollBottom = rootElement.innerHeight + scrollTop
        const scrollHeight = rootElement.scrollHeight
        const isAtPageBottom = Math.abs(scrollHeight - scrollBottom) < scrollOffset
        const headerLinks = Array.from(document.querySelectorAll(headerLinkSelector))
        const headerAnchors = Array.from(rootElement.querySelectorAll(headerAnchorSelector))
        const filteredHeaderAnchors = headerAnchors.filter(anchor => {
            return headerLinks.some(link => link.hash === anchor.hash)
        })
        for (let i = 0; i < filteredHeaderAnchors.length; i++) {
            const currAnchor = filteredHeaderAnchors[i]
            const nextAnchor = filteredHeaderAnchors[i + 1]

            const hasPassedCurrAnchor = scrollTop >= (currAnchor.parentElement?.offsetTop ?? 0) - scrollOffset
            const hasNotPassedNextAnchor = !nextAnchor || scrollTop < (nextAnchor.parentElement?.offsetTop ?? 0) - scrollOffset
            const isActive = hasPassedCurrAnchor && hasNotPassedNextAnchor
            if (!isActive) {
                continue
            }

            const routeHash = decodeURIComponent(router.currentRoute.value.hash)
            const anchorHash = decodeURIComponent(currAnchor.hash)

            if (routeHash === anchorHash) {
                return
            }

            if (isAtPageBottom) {
                for (let j = i + 1; j < filteredHeaderAnchors.length; j++) {
                    const otherHash = decodeURIComponent(filteredHeaderAnchors[j].hash)
                    if (anchorHash === otherHash) {
                        return
                    }
                }
            }

            const { smoothed } = router.currentRoute.query || {}
            if (smoothed) {
                rootElement.scrollTo({ top: currAnchor.offsetTop, left: 0, behavior: 'smooth' })
            }

            replaceWithoutScroll({ hash: anchorHash, force: true })
            break
        }
    }

    const smoothScroll = () => {
        const rootElement = resolveRootElement()
        if (!rootElement) {
            return
        }
        const { smoothed } = router.currentRoute.value.query || {}
        if (smoothed) {
            const targetHash = router.currentRoute.value.hash
            const anchors = Array.from(rootElement.querySelectorAll(headerAnchorSelector))
                .filter(anchor => decodeURIComponent(anchor.hash) === targetHash)
            if (anchors.length > 1) {
                throw new Error("Duplicated Heading!")
            }
            rootElement.scrollTo({ top: (anchors[0].offsetTop - scrollOffset), left: 0, behavior: 'smooth' })
        }
    }

    const onScroll = _.debounce(setRouteActiveHash, debounceDelay)
    const onSmoothScroll = _.debounce(smoothScroll, debounceDelay)

    onMounted(() => {
        const rootElement = resolveRootElement()
        onScroll()
        rootElement.addEventListener('scroll', onScroll)
    })

    onBeforeUnmount(() => {
        const rootElement = resolveRootElement()
        rootElement.removeEventListener('scroll', onScroll)
    })

    watch(() => pageData.value.path, onScroll)
    watch(() => router.currentRoute.value.hash, onSmoothScroll)
}