import { computed, ref } from 'vue'
import { blogPosts } from '@temp/internal/posts'

const currBlogPosts = ref(blogPosts)

const resolveUseBlogPostsOptions = options => {
    const defaultOptions = {
        filter: () => true,
        sorter: () => 1
    }

    return Object.assign(defaultOptions, options)
}

export const useBlogPosts = options => {
    options = resolveUseBlogPostsOptions(options)
    return computed(() => {
        const filteredPosts = currBlogPosts.value.filter(options.filter)
            .sort(options.sorter)

        return filteredPosts
    })
}

if (import.meta.webpackHot || import.meta.hot) {
    __VUE_HMR_RUNTIME__['updateBlogPosts'] = newBlogPosts => {
        currBlogPosts.value = newBlogPosts
    }
}
