import { blogTags } from '@temp/internal/tags'
import { computed, ref } from 'vue'

const currBlogTags = ref(blogTags)

export const useBlogTags = () => {
    return computed(() => {
        return currBlogTags.value
    })
}

if (import.meta.webpackHot || import.meta.hot) {
    __VUE_HMR_RUNTIME__['updateBlogTags'] = tags => {
        currBlogTags.value = tags
    }
}