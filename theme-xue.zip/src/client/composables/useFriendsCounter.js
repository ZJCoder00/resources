import { computed, ref } from 'vue'
import { numFriends } from '@temp/internal/friends'

const currNumFriends = ref(numFriends)

export const useFriendsCounter = () => {
    return computed(() => {
        return currNumFriends.value
    })
}

if (import.meta.webpackHot || import.meta.hot) {
    __VUE_HMR_RUNTIME__['updateNumFriends'] = numFriends => {
        currNumFriends.value = numFriends
    }
}