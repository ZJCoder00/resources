import { defineClientConfig } from "@vuepress/client";
import MyIcon from './components/Icon.vue'

export default defineClientConfig({
    enhance({ app }) {
        app.component('MIcon', MyIcon)
    },
    setup() {
    }
})