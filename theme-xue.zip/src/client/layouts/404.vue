<template>
    <Common>Oh! No page found!</Common>
</template>

<script setup>
    import Common from '@xue/Common.vue'
</script>