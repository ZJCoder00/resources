<template>
    <Common>
        <div class="home">
            <div class="posts">
                <div v-for='(post, index) in posts' :key='index' class="post">
                    <header-image :src='post.headerImage' :to='post.path' hover-effect />
                    <div class="title">
                        <span>{{ post.title }}</span>
                        <tooltip v-if='post.priority > 0' hint='置顶文章'>
                            <span class="set-top">
                                <m-icon name='pushpin-line' size='20px' />
                            </span>
                        </tooltip>
                    </div>
                    <div class="tags">
                        <div class="tag">{{ dayjs(post.date).format('YYYY年MM月DD日') }}</div>
                        <div class="tag">{{ `${processWordCountToString(post.wordCount)} 字` }}</div>
                    </div>
                    <div class="content">
                        <span>{{ post.excerpt === '' ? '暂无摘要' : post.excerpt }}</span>
                        <router-link :to='post.path' class="see-detail">查看全文</router-link>
                    </div>
                </div>
                <Pager :currPage='currPage' :total-pages='totalPages' />
            </div>
        </div>
    </Common>
</template>

<script setup>
    import { onMounted, reactive, ref, computed } from 'vue';
    import { useRoute } from 'vue-router';
    import dayjs from 'dayjs'
    import Common from '@xue/Common.vue'
    import Pager from '@xue/Pager.vue'
    import HeaderImage from '@xue/HeaderImage.vue'
    import Tooltip from '@xue/Tooltip.vue'
    import { useBlogPosts } from '../composables'
    import { processWordCountToString } from '../utils'

    const currRoute = useRoute()
    const blogPosts = useBlogPosts()

    const currPage = computed(() => {
        const { path } = currRoute
        if (path.startsWith('/page')) {
            const slashIndex = path.lastIndexOf('/')
            const page = parseInt(path.substring(slashIndex + 1))
            return isNaN(page) ? 1 : page
        }
        return 1
    })

    const posts = computed(() => {
        // 0: 发布时间降序，1: 发布时间升序
        const { sort = '0' } = currRoute.query
        const startIndex = Math.max(currPage.value - 1, 0) * __POSTS_PER_PAGE__
        const sortedPosts = blogPosts.value.sort((a, b) => {
            if (a.priority !== b.priority) {
                return b.priority - a.priority
            }
            const aDate = dayjs(a.date), bDate = dayjs(b.date)
            if (sort === '0') {
                return bDate.isBefore(aDate) ? 1 : -1
            }
            return bDate.isAfter(aDate) ? 1 : -1
        })
        const endIndex = Math.min(currPage.value * __POSTS_PER_PAGE__, sortedPosts.length)
        return sortedPosts.slice(startIndex, endIndex)
    })

    const totalPages = computed(() => {
        return Math.ceil(blogPosts.value.length / __POSTS_PER_PAGE__)
    })
</script>

<style lang="less" scoped>
    @import '../styles/main.less';

    .home {
        display: flex;
        flex-direction: column;

        .posts {
            display: flex;
            flex-direction: column;
            row-gap: 20px;
            flex: 1;

            .post {
                display: flex;
                flex-direction: column;
                border-bottom: 1px dashed #cecece;
                box-sizing: border-box;
                padding: 0 10px 10px 10px;

                &:last-child {
                    border-bottom: 0;
                }

                .title {
                    display: flex;
                    align-items: center;
                    font-family: 等线;
                    font-size: 24px;
                    margin: 12px 0;
                    column-gap: 12px;

                    .set-top {
                        width: 28px;
                        height: 28px;
                        border-radius: 100%;
                        background: @secondary-color;
                        color: @primary-color;
                        display: flex;
                        justify-content: center;
                        align-items: center;
                    }
                }

                .see-detail {
                    color: @primary-color;
                    margin-left: 4px;
                }

                .tags {
                    display: flex;
                    align-items: center;
                    column-gap: 12px;
                    font-size: 14px;
                    margin-bottom: 8px;

                    .tag {
                        padding: 4px 12px;
                        border-radius: 999px;
                        background: @secondary-color;
                        color: @primary-color;
                    }
                }
            }
        }
    }
</style>