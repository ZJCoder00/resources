<template>
    <Common>This is a useless layout, try to use existing layout!</Common>
</template>

<script setup>
    import Common from '@xue/Common.vue'
</script>

<style></style>