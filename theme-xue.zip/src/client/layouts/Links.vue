<template>
    <Common>
        <div class="links">
            <section-header title='友情链接' sub-title='Friend Links' />
            <div class="categories">
                <div v-for='(category, cIndex) in friendLinks' :key='cIndex' class="category">
                    <div class="title">{{ category.title }}</div>
                    <div v-if='category.friends.length > 0' class="cards">
                        <a v-for='(link, lIndex) in category.friends' :key='`${cIndex}-${lIndex}`' :href='link.url'>
                            <div class="card">
                                <avatar shape='circle' :src='link.avatar' style='width: 64px; height: 64px' />
                                <div class="info">
                                    <div class="username">{{ link.username }}</div>
                                    <div class="description">{{ link.description }}</div>
                                </div>
                            </div>
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </Common>
</template>

<script setup>
    import { computed, ref } from 'vue';
    import { usePageFrontmatter } from '@vuepress/client'
    import SectionHeader from '@xue/SectionHeader.vue'
    import Avatar from '@xue/Avatar.vue'
    import Common from '@xue/Common.vue'

    const frontmatter = usePageFrontmatter()

    const friendLinks = computed(() => {
        return frontmatter.value.categories || []
    })
</script>

<style lang="less" scoped>
    @import "../styles/main.less";

    .links {
        display: flex;
        width: 100%;
        flex-direction: column;
        align-items: flex-start;

        .categories {
            display: flex;
            flex-direction: column;
            margin-top: 24px;
            width: 100%;
            row-gap: 18px;

            .category {
                display: flex;
                flex-direction: column;

                .title {
                    font-size: 18px;
                    border-bottom: 1px dashed #efefef;
                    padding: 0 6px 8px 6px;
                    font-family: 等线;
                }
            }
        }

        .cards {
            display: flex;
            flex-wrap: wrap;
            align-items: flex-start;
            column-gap: 24px;
            row-gap: 16px;
            padding-top: 12px;

            .card {
                padding: 10px 24px;
                border-radius: 6px;
                border: 1px dashed #cecece;
                display: flex;
                align-items: center;
                column-gap: 16px;
                user-select: none;
                transition: border-color 0.4s;
                width: 192px;
                color: #000;

                .info {
                    flex: 1;
                    display: flex;
                    flex-direction: column;
                    row-gap: 8px;
                    font-family: 等线;

                    .username {
                        font-size: 18px;
                        transition: color 0.4s;
                    }

                    .description {
                        font-size: 14px;
                        color: #999;
                    }
                }

                &:hover {
                    cursor: pointer;
                    border-color: @theme-color;

                    .info {
                        .username {
                            color: @primary-color;
                        }
                    }
                }
            }
        }
    }
</style>