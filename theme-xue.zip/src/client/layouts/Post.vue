<template>
    <Common is-post>
        <div class="page-post">
            <header-image :src='headerImageSrc' to='#' />
            <div class="heading-part">
                <div class="title">{{ pageTitle }}</div>
                <div class="info">
                    <tags :items='postInfo' style='font-size: 14px' />
                </div>
            </div>
            <div class="theme-content">
                <Content />
            </div>
            <div class="footer">
                <span>最后编辑时间：{{ modifiedAt }}</span>
            </div>
        </div>
    </Common>
</template>

<script setup>
    import { computed, onMounted, ref } from 'vue'
    import { usePageFrontmatter, Content, usePageData } from '@vuepress/client'
    import dayjs from 'dayjs'
    import HeaderImage from '@xue/HeaderImage.vue'
    import Tags from '@xue/Tags.vue'
    import Common from '@xue/Common.vue'
    import { processWordCountToString } from '../utils'

    const frontmatter = usePageFrontmatter()
    const pageData = usePageData()

    const headerImageSrc = computed(() => {
        return frontmatter.value.headerImage
    })

    const pageTitle = computed(() => {
        // 如果Frontmatter有title，则其优先级更高
        // 否则选用一级标题
        if (frontmatter.value.title) {
            return frontmatter.value.title
        }
        return pageData.value.title
    })

    // 0 - time
    // 1 - wordcount
    const postInfo = computed(() => {
        let dateStr
        if (frontmatter.value.date) {
            dateStr = dayjs(frontmatter.value.date).format('YYYY-MM-DD')
        } else {
            const date = dayjs(pageData.value.git.createdTime)
            dateStr = date.format('YYYY-MM-DD')
        }

        const writtenDate = { name: dateStr, icon: 'timer-fill' }
        const wordCounts = { name: `${processWordCountToString(pageData.value.wordCount)} 字` }

        return [writtenDate, wordCounts]
    })

    const modifiedAt = computed(() => {
        const date = dayjs(pageData.value.git.updatedTime)

        return date.format('YYYY-MM-DD HH:mm:ss')
    })
</script>

<style lang="less">
    @import "../styles/md.less";

    .page-post {
        display: flex;
        width: 100%;
        flex-direction: column;
        padding: 0 10px 10px 10px;
        box-sizing: border-box;

        .heading-part {
            display: flex;
            flex-direction: column;
            row-gap: 12px;
            margin-top: 12px;

            .title {
                font-family: 等线;
                font-size: 2.2em;
            }
        }

        .footer {
            display: flex;
            flex-direction: column;
            row-gap: 12px;
            align-items: flex-end;
            width: 100%;
            font-size: 14px;
            color: #999;
        }
    }
</style>