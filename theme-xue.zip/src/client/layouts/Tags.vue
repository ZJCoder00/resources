<template>
    <Common>
        <div class="page-tags">
            <section-header title='标签' sub-title='Tags' />
            <div class="tags">
                <router-link
                    v-for='(tag, index) in allTags'
                    :key='index'
                    :to="`/tags/${tag.name !== '全部' ? tag.name : ''}`"
                    :class="['tag', tag.active ? 'active' : '']"
                >
                    <span>{{ tag.name }}</span>
                    <span>{{ tag.amount }}</span>
                </router-link>
            </div>
            <div class="posts">
                <div v-for='(post, index) in filteredPosts' :key='index' class="post">
                    <div class="title">{{ post.title }}</div>
                    <div class="body">
                        <span class="abstraction">{{ post.excerpt === '' ? '暂无摘要' : post.excerpt }}</span>
                        <router-link class="see-detail" :to='post.path'>查看全文</router-link>
                    </div>
                </div>
            </div>
            <div class="pager-wrapper">
                <pager
                    :curr-page='currPage'
                    :total-pages='totalPages'
                    align='center'
                    :prefix='pagerPrefix'
                />
            </div>
        </div>
    </Common>
</template>

<script setup>
    import { computed, ref } from 'vue';
    import { useRoute } from 'vue-router';
    import SectionHeader from '@xue/SectionHeader.vue'
    import Pager from '@xue/Pager.vue'
    import Common from '@xue/Common.vue'
    import { useBlogPosts, useBlogTags } from '../composables'
    import { removeExtension } from '../utils'

    const blogTags = useBlogTags()
    const blogPosts = useBlogPosts()
    const currRoute = useRoute()

    const currTag = computed(() => {
        // /tags/abc/1
        // /tags/abc
        // /tags/3
        // /tags
        const { path } = currRoute
        const parts = path.split('/').slice(1)
        if (parts.length === 1) {
            return null
        }
        const isDigit = /^[0-9]+$/.test(parts[1])
        if (isDigit || parts[1].length < 1) {
            return null
        }
        const decodedTag = decodeURIComponent(parts[1])
        return decodedTag
    })

    const allTags = computed(() => {
        const tags = []
        const tag = currTag.value
        for (const entry of Object.entries(blogTags.value)) {
            const [name, amount] = entry
            const active = tag === name
            tags.push({ name, amount, active })
        }
        // 先对提取出来的标签进行排序
        // 然后将`全部`这个总标签加入到数组头部
        tags.sort((a, b) => b.amount - a.amount)
        .unshift({ name: '全部', amount: blogPosts.value.length, active: !tag })

        return tags
    })

    const filteredPosts = computed(() => {
        const tag = currTag.value
        if (!tag) {
            return blogPosts.value
        }
        const posts = blogPosts.value.filter(post => post.tags.includes(tag))
        const startIndex = Math.max(__POSTS_PER_PAGE__ * (currPage.value - 1), 0)
        const endIndex = Math.min(__POSTS_PER_PAGE__ * currPage.value, posts.length)
        return posts.slice(startIndex, endIndex)
    })

    const currPage = computed(() => {
        // /tags/abc/1
        // /tags/abc
        // /tags/3
        // /tags
        const { path } = currRoute
        const parts = path.split('/').slice(1)
        if (parts.length === 1) {
            return 1
        }
        const page = parseInt(parts.pop())
        return isNaN(page) ? 1 : page
    })

    const totalPages = computed(() => {
        return Math.ceil(filteredPosts.value.length / __POSTS_PER_PAGE__)
    })

    const pagerPrefix = computed(() => {
        if (!currTag.value) {
            return '/tags/'
        }
        return `/tags/${currTag.value}/`
    })
</script>

<style lang="less" scoped>
    @import "../styles/main.less";

    .page-tags {
        display: flex;
        flex-direction: column;
        align-items: flex-start;
        width: 100%;

        .tags {
            display: flex;
            align-items: flex-start;
            flex-wrap: wrap;
            row-gap: 16px;
            column-gap: 12px;
            margin-top: 18px;
            padding-bottom: 12px;
            border-bottom: 1px dashed #cecece;
            width: 100%;

            .tag {
                padding: 4px 12px;
                color: #999;
                background: #efefef;
                border-radius: 999px;
                transition: color 0.4s, background 0.4s;
                font-weight: bold;
                font-size: 14px;
                display: flex;
                column-gap: 8px;
                user-select: none;

                &.active, &:hover {
                    color: @primary-color;
                    background: @secondary-color;
                }

                &:hover {
                    cursor: pointer;
                }
            }
        }

        .posts {
            display: flex;
            flex-direction: column;
            margin: 12px 0;
            width: 100%;
            row-gap: 12px;

            .post {
                display: flex;
                flex-direction: column;
                padding: 0 0 8px 8px;
                border-bottom: 1px dashed #cecece;
                row-gap: 8px;

                .title {
                    font-size: 22px;
                    font-family: 等线;
                }

                .see-detail {
                    color: @primary-color;
                    margin-left: 8px;
                }
            }
        }

        .pager-wrapper {
            display: flex;
            justify-content: center;
            width: 100%;
        }
    }
</style>