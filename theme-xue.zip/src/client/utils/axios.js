import axios from 'axios'

export const get = (url, params) => axios.get(url, { params })
export const post = (url, data) => axios.post(url, { data })
