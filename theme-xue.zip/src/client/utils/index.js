export const clamp = (value, min, max) => Math.max(Math.min(value, max), min)
export const removeExtension = string => {
    const dotIndex = string.lastIndexOf('.')
    if (dotIndex > -1 && dotIndex < string.length - 1) {
        return string.substring(0, dotIndex)
    }
    return string
}
export const processWordCountToString = wordCount => {
    if (wordCount >= 1000000) {
        return `${(wordCount / 1000000).toFixed(1)}m`
    } else if (wordCount >= 100) {
        return `${(wordCount / 1000).toFixed(1)}k`
    }
    return wordCount
}
