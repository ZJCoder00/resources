// 统计信息的插件
// 目前可以统计的数据有：
/*
    numFriends: 如果有页面的布局是Links，则会统计其友链的个数，是每个分类的友链个数之和
    tags: 对于布局为Post的页面，会统计每个页面的标签，并存储在该字段中
*/
const { createPage, preparePageComponent, preparePageData, preparePagesComponents, preparePagesData, preparePagesRoutes } = require('@vuepress/core')
const { watch } = require('chokidar')
const { path } = require('@vuepress/utils')
const { generateHMRCode, slugify } = require('./utils')

const resolveGetStatisticsOptions = options => {
    const defaultOptions = {
        generateTagsPage: true,
        generateHomePage: true,
        postsPerPage: 10, // 标签页和主页的分页配置，每一页最多可以存在的文章数量
        hotReload: true // 是否启用热重载
    }

    return Object.assign(defaultOptions, options)
}

const generatePage = async (app, { path, frontmatter }) => {
    return await createPage(app, { path, frontmatter })
}

const prepareCountFriends = async (app) => {
    const hmrCode = generateHMRCode('updateNumFriends', 'numFriends')
    let numFriends = 0
    for (const page of app.pages) {
        if (page.frontmatter.layout === 'Links') {
            const { categories } = page.frontmatter
            for (const friendCategory of categories) {
                numFriends += friendCategory.friends.length
            }
            break
        }
    }
    await app.writeTemp('internal/friends.js', `export const numFriends = ${numFriends}\n${hmrCode}`)
}

// 键是标签名称，值是标签被文章使用的次数
const prepareTags = async (app, options) => {
    const blogTags = {}
    // 遍历每一个页面
    // 获取每个页面使用的标签
    for (const page of app.pages) {
        const { tags, hide } = page.frontmatter
        // 如果没有标签，或者页面被设置为隐藏则不会进行记录
        if (!tags || hide) {
            continue
        }
        for (const tag of tags) {
            if (!(tag in blogTags)) {
                blogTags[tag] = 0
            }
            blogTags[tag]++
        }
    }
    // 是否需要生成标签页面
    if (options.generateTagsPage) {
        for (const tag of Object.keys(blogTags)) {
            const frontmatter = { layout: 'Tags', title: `标签页 | ${tag}` }
            // 计算每个标签总共可被分为多少页
            const totalPages = Math.ceil(blogTags[tag] / options.postsPerPage)
            // 生成对应的页面路由
            for (let i = 1; i <= totalPages; i++) {
                const page = await generatePage(app, { path: `/tags/${tag}/${i}`, frontmatter })
                app.pages.push(page)
            }
            // 生成每个标签第一页的别名
            const page = await generatePage(app, { path: `/tags/${tag}`, frontmatter })
            app.pages.push(page)
        }
        // 生成首页
        let totalBlogs = 0
        for (const value of Object.values(blogTags)) {
            totalBlogs += value
        }
        const allTotalPages = Math.ceil(totalBlogs / options.postsPerPage)
        for (let i = 1; i <= allTotalPages; i++) {
            const page = await generatePage(app, { path: `/tags/${i}`, frontmatter: { layout: 'Tags', title: '标签页 | 全部' } })
            app.pages.push(page)
        }
    }
    const hmrCode = generateHMRCode('updateBlogTags', 'blogTags')
    await app.writeTemp('internal/tags.js', `export const blogTags = ${JSON.stringify(blogTags)};\n${hmrCode}`)
    return blogTags
}

const preparePosts = async (app, options) => {
    const blogPosts = []
    for (const page of app.pages) {
        const { layout, hide } = page.frontmatter
        // 首先，该页面得使用Post布局
        // 其次，该页面没有被隐藏
        if (layout === 'Post' && !hide) {
            const { title, excerpt, date, path } = page
            const { headerImage = '', tags = [], priority = 0 } = page.frontmatter
            const { wordCount } = page.data
            const post = { title, excerpt, date, headerImage, path, tags, priority, wordCount }
            blogPosts.push(post)
        }
    }
    if (options.generateHomePage) {
        const numPages = Math.ceil(blogPosts.length / options.postsPerPage)
        const frontmatter = { layout: 'Home' }
        for (let i = 1; i <= numPages; i++) {
            const page = await generatePage(app, { path: `/page/${i}`, frontmatter })
            app.pages.push(page)
        }
    }
    const hmrCode = generateHMRCode('updateBlogPosts', 'blogPosts')
    await app.writeTemp('internal/posts.js', `export const blogPosts = ${JSON.stringify(blogPosts)};\n${hmrCode}`)
    return blogPosts
}

const getStatisticsPlugin = options => {
    options = resolveGetStatisticsOptions(options)
    let keySet = null
    return app => ({
        name: 'xue-plugin-statistics',
        onInitialized: async app => {
            await prepareCountFriends(app)
            await prepareTags(app, options)
            await preparePosts(app, options)
            keySet = new Set()
            for (const page of app.pages) {
                keySet.add(page.key)
            }
        },
        onWatched: (app, watchers) => {
            if (!options.hotReload) {
                return
            }
            // 监听文章的文件变化
            const postsWatcher = watch('pages/posts/**/*.js', { cwd: app.dir.temp(), ignoreInitial: true })
            // 如果有文件改名或者被删除，则需要重新整理app.pages
            // 否则在开发过程中会产生大量的冗余路径信息
            const updatePostsAndTags = async () => {
                await prepareTags(app, options)
                await preparePosts(app, options)
                const newKeySet = new Set()
                const newlyAddedKeys = [], toBeRemoved = []
                for (const page of app.pages) {
                    const key = page.key
                    if (!keySet.has(key)) {
                        newlyAddedKeys.push(key)
                    }
                    newKeySet.add(key)
                }
                for (const key of keySet.values()) {
                    if (!newKeySet.has(key)) {
                        toBeRemoved.push(key)
                    }
                }
                // 添加新的页面信息
                for (const pageKey of newlyAddedKeys) {
                    const page = app.pages.find(page => page.key === pageKey)
                    await preparePageComponent(app, page)
                    await preparePageData(app, page)
                }

                // 移除已经被删除的文章路径
                for (const key of toBeRemoved) {
                    const pageIndex = app.pages.findIndex(page => page.key === key)
                    if (pageIndex >= 0) {
                        app.pages.splice(pageIndex, 1)
                    }
                }

                // 只要有一个文章被添加或者删除，就要更新数据
                await preparePagesComponents(app)
                await preparePagesData(app)
                await preparePagesRoutes(app)

                keySet = newKeySet
            }
            postsWatcher.on('add', () => {
                updatePostsAndTags()
            })
            postsWatcher.on('change', () => {
                updatePostsAndTags()                
            })
            postsWatcher.on('unlink', () => {
                updatePostsAndTags()
            })
            // 监听友链文章的变化
            let friendLinkFilePath = ''
            for (const page of app.pages) {
                if (page.frontmatter.layout === 'Links') {
                    friendLinkFilePath = page.filePath
                    break
                }
            }
            const trimmedFilePath = path.basename(friendLinkFilePath, path.extname(friendLinkFilePath))
            const linkWatcher = watch(`pages/${trimmedFilePath}.html.js`, { cwd: app.dir.temp(), ignoreInitial: true })
            const updateFriendLinks = async () => {
                await prepareCountFriends(app)
            }
            linkWatcher.on('add', () => {
                updateFriendLinks()
            })
            linkWatcher.on('change', () => {
                updateFriendLinks()
            })
            linkWatcher.on('unlink', () => {
                updateFriendLinks()
            })
            watchers.push(postsWatcher, linkWatcher)
        }
    })
}

module.exports = getStatisticsPlugin