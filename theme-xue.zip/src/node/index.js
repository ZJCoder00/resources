// Vuepress stuffs
const { fs, path } = require('@vuepress/utils')
// Plugins etc
// 这个插件可以将用户传入的配置注入客户端文件中
const { themeDataPlugin } = require('@vuepress/plugin-theme-data')
// 统计字数插件，参考: https://github.com/vuepress-theme-hope/vuepress-theme-hope/blob/main/packages/reading-time2/src/node/readingTime.ts
const wordCountPlugin = require('./wordCount')
// Git仓库插件
const { gitPlugin } = require('@vuepress/plugin-git')
// 统计数据插件
const statisticsPlugin = require('./getStatistics')
// themePlugins: 主题插件配置对象，
// 你可以通过传入一个对象来启用和配置这些插件
// Layout一览
// Post 博文布局
/*
    对于博文布局，以下字段你必须设置：
    title，文章的标题
    description，文章的描述
    headerImage，头图的路径，可以是本地路径，也可以是网络地址
*/
// Tags 标签布局
// Home 主页布局
// Links 友链布局
/*
    对于友链布局，你需要在Frontmatter里填写一个数组字段：`categories`
    其每个元素都是一个对象，结构如下
    {
        title: string // 表示类别的名称
        friends: { // 友链数组
            username: string // 好友的用户名
            description: string // 好友的简介
            avatar: string // 好友的头像网址
            url: string // 好友的博客网址
        }[]
    }
*/
/*
    {
        defaultBackground: 博客背景图片，选填。默认是public下的bg.jpg
        postFolder: string // 文章文件夹路径，用于获取文章数，默认路径是/posts/
                           // 表示你所有的文章只有放在docs目录下的posts文件夹里才会算入文章
        postsPerPage: number // 每一页的文章数量，选填，默认为10
        navBar: {
            [key: string]: string // 这里的key就是文件名，值是导航栏中的名字
        },
        user: { // 博主信息设置
            name: string // 你的昵称
            bio: string // 个人简介
            avatar: string // 头像的URL，可以是本地public目录下的也可以是网络图片
        },
        social: [ // 社交账号设置
            {
                title: string // 网站名称
                icon: string // 图标名称，本主题使用Remixicon，图标的名字是去掉`ri-`前缀后的名称
                url: string // 目标网站个人主页的网址
            }    
        ],
        weatherApi: { // 天气API配置
            appId: string // 申请得到的appid
            appSecret: string // 申请得到的密钥
        }
    }
*/
const resolveThemeOptions = (options = {}) => {
    const defaultOptions = {
        defaultBackground: '/bg.jpg',
        postFolder: '/posts/',
        postsPerPage: 10,
        navBar: {
            '/': '首页'
        },
        user: {
            username: '无名氏',
            bio: '暂无简介',
            avatar: ''
        },
        social: [],
        weatherApi: {
            appId: 'Input your appId!',
            appSecret: 'Input your appSecret1'
        }
    }

    return Object.assign(defaultOptions, options)
}

const xueTheme = ({ themePlugins = {}, ...otherOptions } = {}) => {
    otherOptions = resolveThemeOptions(otherOptions)

    return {
        name: 'theme-xue',
        layouts: path.resolve(__dirname, '../client/layouts'),
        alias: {
            '@xue': path.resolve(__dirname, '../client/components')
        },
        define: {
            __POST_FOLDER__: otherOptions.postFolder,
            __POSTS_PER_PAGE__: otherOptions.postsPerPage
        },
        templateBuild: path.resolve(__dirname, '../../templates/build.html'),
        clientConfigFile: path.resolve(__dirname, '../client/config.js'),
        extendsMarkdownOptions: (options, app) => {
            if (!options.extractTitle) {
                options.extractTitle = true
            }
        },
        extendsPage: page => {
            // TODO
        },
        plugins: [
            gitPlugin({ contributors: false }),
            themeDataPlugin({ themeData: otherOptions }),
            wordCountPlugin(),
            statisticsPlugin()
        ]
    }
}

module.exports = xueTheme
