const postEncryptionPlugin = options => {

    return app => ({
        name: 'xue-plugin-encryption',
        extendsPage: page => {}
    })
}