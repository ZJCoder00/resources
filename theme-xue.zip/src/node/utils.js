const generateHMRCode = (updateFnName, updateFnParams) => {
    if (Array.isArray(updateFnParams)) {
        updateFnParams = updateFnParams.join(',')
    }
    // First is webpack part
    let generatedCode = `if(import.meta.webpackHot){import.meta.webpackHot.accept();if(__VUE_HMR_RUNTIME__.${updateFnName}){__VUE_HMR_RUNTIME__.${updateFnName}(${updateFnParams})}}`
    // Next is Vite part
    generatedCode += `if(import.meta.hot){import.meta.hot.accept(({${updateFnParams}}) => __VUE_HMR_RUNTIME__.${updateFnName}(${updateFnParams}))}`
    return generatedCode
}

const slugify = name => name.replace(/[ _]/g, '-').replace(/[:?*|\\/<>]/g, '').toLowerCase()

module.exports = {
    generateHMRCode,
    slugify
}