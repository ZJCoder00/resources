// 统计字数

const getLatinWords = content => {
    return content.match(/[\w\d\s,.\u00C0-\u024F\u0400-\u04FF]+/giu) || []
}

const getChineseWords = content => {
    return content.match(/[\u4E00-\u9FD5]/gu) || []
}

const countWords = content => {
    const numLatinWords = getLatinWords(content).reduce((accumulator, word) => {
        return accumulator + (word.trim() === '' ? 0 : word.trim().split(/\s+/u).length)
    }, 0)
    const numChineseWords = getChineseWords(content).length

    return numLatinWords + numChineseWords
}

const wordCountPlugin = () => {
    return app => ({
        name: 'xue-plugin-word-count',
        extendsPage: page => {
            // 只统计Post布局的文章的字数
            const { layout = 'Layout' } = page.frontmatter
            if (layout === 'Home' || layout === 'Links' || layout === 'Tags' || layout === 'Layout') {
                return
            }
            page.data.wordCount = countWords(page.content)
        }
    })
}

module.exports = wordCountPlugin